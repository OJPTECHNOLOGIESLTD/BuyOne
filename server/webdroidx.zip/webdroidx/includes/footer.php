<?php include_once ('assets/js.min.php'); ?>
</body>
</html>