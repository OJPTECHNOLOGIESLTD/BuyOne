<link rel="icon" href="assets/images/favicon.png" type="image/x-icon">
<link href="https://fonts.googleapis.com/css?family=Roboto:400,700&subset=latin,cyrillic-ext" rel="stylesheet" type="text/css">
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet" type="text/css">
<link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet">
<link href="assets/css/bootstrap.css" rel="stylesheet">
<link href="assets/css/waves.css" rel="stylesheet" />
<link href="assets/css/animate.css" rel="stylesheet" />
<link href="assets/css/theme.css" rel="stylesheet" />
<link href="assets/css/bootstrap-select.css" rel="stylesheet" />
<link href="assets/css/styles.min.css" rel="stylesheet">
<link href="assets/plugins/dropify/css/dropify.css" rel="stylesheet">
<script src="assets/js/jquery-1.9.1.min.js"></script>